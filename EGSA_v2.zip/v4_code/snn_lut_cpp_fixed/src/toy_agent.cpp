// Toy EGSA agent built on top of the v4 LUT project.
//
// This program demonstrates a simplified entropy‑aware agent that
// maintains per‑leaf statistics and makes decisions based on
// confidence, risk and certainty.  It does not interact with the
// full SNN model; instead, it uses random scores and rewards to
// illustrate the mechanics of the EGSA architecture.
//
// The leaf structure defined in lut.hpp has been extended with
// additional fields (mean_reward, mean_confidence, mean_risk,
// mean_certainty) which are updated here.  See EGSA_spec.md for
// details【260323914150634†L467-L503】.

#include "lut.hpp"
#include <cmath>
#include <iostream>
#include <random>
#include <unordered_map>
#include <vector>

// Structure to hold decision outcome and associated meta‑values.
struct DecisionPacket {
  std::string action;
  double confidence;
  double risk;
  double certainty;
  double evidence_value;
  std::string query;
};

// Toy agent implementing a simplified EGSA loop.
class ToyAgent {
public:
  ToyAgent(unsigned int seed = 0)
      : gen(seed), dist01(0.0, 1.0) {}

  // Run for a given number of steps, printing the decision at each step.
  void run(int steps = 10) {
    for (int t = 0; t < steps; ++t) {
      DecisionPacket dp = step();
      std::cout << "Step " << t << ": action=" << dp.action << ", conf="
                << dp.confidence << ", risk=" << dp.risk << ", cert="
                << dp.certainty << ", ev=" << dp.evidence_value;
      if (!dp.query.empty()) std::cout << ", query=" << dp.query;
      std::cout << '\n';
      update_after_step(dp);
    }
  }

private:
  // Internal representation of a leaf in this toy.  We reuse the
  // extended fields of LUT::Leaf but add a base_score for diversity.
  struct LeafState {
    LUT::Leaf stats;
    double base_score;
    // Default constructor: initialize base_score to zero.  This is
    // required because std::unordered_map::operator[] will
    // default-construct a LeafState when a key does not exist.
    LeafState() : base_score(0.0) {}
    LeafState(double base) : base_score(base) {}
  };

  // Random number generation.
  std::mt19937 gen;
  std::uniform_real_distribution<double> dist01;

  // Map leaf IDs to leaf states.
  std::unordered_map<int, LeafState> leaves;
  int next_leaf_id = 0;

  // Calibration history: pairs of (predicted confidence, success).
  std::vector<std::pair<double, double>> calibration_history;

  // Compute U‑shaped uncertainty function: 0.5/(1+|u|).
  static double uncertainty_u(double u) {
    return 0.5 / (1.0 + std::abs(u));
  }

  // Softmax helper.
  static std::vector<double> softmax(const std::vector<double> &xs) {
    double max_x = xs.empty() ? 0.0 : xs[0];
    for (double x : xs)
      if (x > max_x)
        max_x = x;
    std::vector<double> exps;
    exps.reserve(xs.size());
    double sum = 0.0;
    for (double x : xs) {
      double v = std::exp(x - max_x);
      exps.push_back(v);
      sum += v;
    }
    if (sum <= 0.0)
      sum = 1.0;
    std::vector<double> out;
    out.reserve(xs.size());
    for (double e : exps)
      out.push_back(e / sum);
    return out;
  }

  // Retrieve or create a leaf ID.  With probability 0.3 create a new one.
  int get_leaf_id() {
    if (leaves.empty() || dist01(gen) < 0.3) {
      double base = dist01(gen);
      leaves.emplace(next_leaf_id, LeafState(base));
      return next_leaf_id++;
    }
    // Pick a random existing leaf ID.
    auto it = leaves.begin();
    std::advance(it, (int)(dist01(gen) * leaves.size()));
    return it->first;
  }

  // Compute certainty based on recent calibration history.
  double compute_certainty(double predicted_conf) {
    if (calibration_history.empty())
      return 0.5;
    int n = 0;
    double sum_err = 0.0;
    for (auto it = calibration_history.rbegin(); it != calibration_history.rend() && n < 10; ++it, ++n) {
      double pred = it->first;
      double outcome = it->second;
      sum_err += std::abs(pred - outcome);
    }
    double avg_err = sum_err / static_cast<double>(n);
    return std::max(0.0, 1.0 - avg_err);
  }

  // Simulate a reward based on the chosen action.
  double simulate_reward(const std::string &action) {
    if (action == "answer")
      return dist01(gen);
    if (action == "gather")
      return dist01(gen) * 0.2 - 0.1; // Uniform in [-0.1,0.1]
    return dist01(gen) * (-0.05); // Negative small for pass
  }

  // One decision step: compute scores, risk, confidence and decide action.
  DecisionPacket step() {
    // Candidate actions.
    static const std::vector<std::string> actions = {"answer", "gather", "pass"};
    std::vector<int> lids;
    lids.reserve(actions.size());
    // For each action, pick or create a leaf and compute a score.
    std::vector<double> scores;
    for (size_t i = 0; i < actions.size(); ++i) {
      int lid = get_leaf_id();
      lids.push_back(lid);
      LeafState &ls = leaves[lid];
      // Score: base + mean_reward - mean_risk + exploration bonus.
      double explore = 0.1 / (1.0 + ls.stats.count);
      double score = ls.base_score + ls.stats.mean_reward - ls.stats.mean_risk + explore;
      scores.push_back(score);
    }
    // Compute softmax to get confidence distribution.
    std::vector<double> probs = softmax(scores);
    // Choose best action.
    size_t best_idx = 0;
    for (size_t i = 1; i < probs.size(); ++i)
      if (probs[i] > probs[best_idx])
        best_idx = i;
    const std::string &chosen_action = actions[best_idx];
    double confidence = probs[best_idx];
    // Compute risk as U(diff between top two scores).
    double risk = 0.0;
    if (scores.size() >= 2) {
      // Find top two
      double max1 = scores[0], max2 = -1e9;
      for (double s : scores) {
        if (s > max1) {
          max2 = max1;
          max1 = s;
        } else if (s > max2) {
          max2 = s;
        }
      }
      double diff = max1 - max2;
      risk = uncertainty_u(diff);
    }
    // Evidence value equals risk in this toy.
    double evidence_value = risk;
    // Certainty computed from calibration history.
    double certainty = compute_certainty(confidence);
    // Commit decision threshold.  If commit score too low, gather instead.
    double lambda = 1.0;
    double mu = 1.0;
    double threshold = 0.2;
    double commit_score = confidence * certainty - lambda * risk + mu * evidence_value;
    std::string action = chosen_action;
    std::string query;
    if (commit_score <= threshold && chosen_action != "gather") {
      action = "gather";
      query = "lookup";
    }
    return DecisionPacket{action, confidence, risk, certainty, evidence_value, query};
  }

  // Update after decision: simulate reward and update leaf statistics and calibration.
  void update_after_step(const DecisionPacket &dp) {
    double reward = simulate_reward(dp.action);
    double success = reward > 0.0 ? 1.0 : 0.0;
    calibration_history.emplace_back(dp.confidence, success);
    // Update one of the leaves corresponding to the chosen action.  For
    // simplicity, update all leaves to see effect of learning.  In a
    // real agent, you would update only the leaf that generated the
    // decision.
    for (auto &kv : leaves) {
      auto &ls = kv.second;
      ls.stats.count += 1;
      // Update running averages.
      double alpha = 1.0 / static_cast<double>(ls.stats.count);
      ls.stats.mean_reward = (1.0 - alpha) * ls.stats.mean_reward + alpha * reward;
      ls.stats.mean_confidence = (1.0 - alpha) * ls.stats.mean_confidence + alpha * dp.confidence;
      ls.stats.mean_risk = (1.0 - alpha) * ls.stats.mean_risk + alpha * dp.risk;
      ls.stats.mean_certainty = (1.0 - alpha) * ls.stats.mean_certainty + alpha * dp.certainty;
      // Importance EMA: magnitude of reward update.
      ls.stats.importance_ema = 0.99 * ls.stats.importance_ema + 0.01 * std::abs(reward);
    }
    // Occasionally prune leaves that have not been visited and have low importance.
    if (dist01(gen) < 0.1) {
      prune_leaves(1, 0.05);
    }
  }

  // Remove leaves that have low count and low importance.
  void prune_leaves(int min_count, double min_importance) {
    std::vector<int> to_remove;
    for (const auto &kv : leaves) {
      const LeafState &ls = kv.second;
      if (ls.stats.count < (unsigned int)min_count && ls.stats.importance_ema < min_importance) {
        to_remove.push_back(kv.first);
      }
    }
    for (int id : to_remove) {
      leaves.erase(id);
    }
  }
};

int main() {
  ToyAgent agent(1234);
  agent.run(20);
  return 0;
}