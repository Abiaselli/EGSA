#pragma once
#include "config.hpp"
#include "rng.hpp"
#include "lut.hpp"
#include <vector>
#include <cstring>
#include <cmath>
#include <algorithm>

inline void softmax_inplace(float* x, int n, float temp) {
  float mx = x[0];
  for (int i = 1; i < n; i++) mx = std::max(mx, x[i]);
  float sum = 0.0f;
  for (int i = 0; i < n; i++) { x[i] = std::exp((x[i]-mx)/temp); sum += x[i]; }
  float inv = 1.0f / (sum + 1e-20f);
  for (int i = 0; i < n; i++) x[i] *= inv;
}

inline int sample_from_probs(const float* p, int n, RNG& rng) {
  float coin = rng.uniform01();
  float cdf = 0.0f;
  for (int i = 0; i < n; i++) {
    cdf += p[i];
    if (coin < cdf) return i;
  }
  return n-1;
}


struct EGSAPacket {
  float confidence = 0.0f;
  float risk = 1.0f;
  float certainty = 0.5f;
  float entropy = 1.0f;
  float delta_entropy = 0.0f;
  float target_prob = 0.0f;
  float correct_rate = 0.0f;
  float commit_score = -1.0f;
  float applied_lr_scale = 0.0f;
  int retries_used = 0;
  bool committed = false;
};

struct EGSAState {
  float entropy_ema = 1.0f;
  float confidence_ema = 0.0f;
  float certainty_ema = 0.5f;
  float risk_ema = 1.0f;
  float correct_rate_ema = 0.0f;
  uint64_t committed_steps = 0;
  uint64_t skipped_steps = 0;
  uint64_t total_retries = 0;
};

struct AttentionHead {
  HyperParams hp;
  LUT V; // total_n_c = n_c + n_c + positional_dim, y_dim = embedding_dim
  std::vector<float> positional; // [context][n_t][pos_dim]
  std::vector<LUTCache> V_cache; // [context]
  std::vector<LUTCache> PE_cache;// [context] (by relative position)

  void init(const HyperParams& hp_, RNG& rng) {
    hp = hp_;
    V.init(hp, rng, hp.n_c + hp.n_c + hp.positional_dim, hp.embedding_dim);

    positional.resize((size_t)hp.context * (size_t)hp.n_t * (size_t)hp.positional_dim);
    for (auto& v : positional) v = rng.uniform_signed(1.0f);

    V_cache.resize((size_t)hp.context);
    PE_cache.resize((size_t)hp.context);
    for (int i = 0; i < hp.context; i++) {
      V_cache[(size_t)i] = V.make_cache();
      PE_cache[(size_t)i] = V.make_cache();
    }
  }

  const float* pos_ptr(int rel_pos) const {
    return &positional[(size_t)rel_pos * (size_t)hp.n_t * (size_t)hp.positional_dim];
  }

  void forward(const float* x /*[context][emb]*/, float* y /*[context][emb]*/) {
    for (int pos = 0; pos < hp.context; pos++) {
      V.cache_index(&x[(size_t)pos * (size_t)hp.embedding_dim], V_cache[(size_t)pos]);
      V.cache_pe_index(pos_ptr(pos), PE_cache[(size_t)pos]);
    }

    for (int pos = 1; pos < hp.context; pos++) {
      float* y_pos = &y[(size_t)pos * (size_t)hp.embedding_dim];
      for (int pos1 = 0; pos1 < pos; pos1++) {
        const auto& cQ  = V_cache[(size_t)pos];
        const auto& cK  = V_cache[(size_t)pos1];
        const auto& cPE = PE_cache[(size_t)(pos - pos1)];

for (int i = 0; i < hp.n_t; i++) {
  uint32_t leaf = concat_leaf(hp, cQ.j[(size_t)i], cK.j[(size_t)i], cPE.j[(size_t)i]);
  const float* w = V.leaf_const(i, leaf);
  if (!w) continue;
  for (int k = 0; k < hp.embedding_dim; k++) y_pos[k] += w[(size_t)k];
}
      }
    }
  }

  void backward(float* x_grad, const float* y_grad, float lr) {
    std::vector<float> pos_grad(positional.size(), 0.0f);

    for (int pos = 1; pos < hp.context; pos++) {
      const float* yg = &y_grad[(size_t)pos * (size_t)hp.embedding_dim];

      for (int pos1 = 0; pos1 < pos; pos1++) {
        auto& cQ  = V_cache[(size_t)pos];
        auto& cK  = V_cache[(size_t)pos1];
        auto& cPE = PE_cache[(size_t)(pos - pos1)];

        float* xgQ = &x_grad[(size_t)pos  * (size_t)hp.embedding_dim];
        float* xgK = &x_grad[(size_t)pos1 * (size_t)hp.embedding_dim];

        for (int i = 0; i < hp.n_t; i++) {
          int jQ  = cQ.j[(size_t)i];
          int jK  = cK.j[(size_t)i];
          int jPE = cPE.j[(size_t)i];

          uint32_t leaf = concat_leaf(hp, jQ, jK, jPE);

          float uQ  = std::fabs(cQ.u_min[(size_t)i]);
          float uK  = std::fabs(cK.u_min[(size_t)i]);
          float uPE = std::fabs(cPE.u_min[(size_t)i]);

          if (uQ < uK) {
            int jQb = jQ ^ (1 << cQ.r_min[(size_t)i]);
            uint32_t leaf_bar = concat_leaf(hp, jQb, jK, jPE);

            float gi = 0.0f;
const float* w  = V.leaf_const(i, leaf);
const float* wb = V.leaf_const(i, leaf_bar);
for (int k = 0; k < hp.embedding_dim; k++) {
  float wk  = w  ? w[(size_t)k]  : 0.0f;
  float wbk = wb ? wb[(size_t)k] : 0.0f;
  gi += yg[(size_t)k] * (wbk - wk);
}
            float v = gi * Up(cQ.u_min[(size_t)i]);

            int idx = i*hp.n_c + cQ.r_min[(size_t)i];
            xgQ[V.a[(size_t)idx]] += v;
            xgQ[V.b[(size_t)idx]] -= v;
          } else {
            int jKb = jK ^ (1 << cK.r_min[(size_t)i]);
            uint32_t leaf_bar = concat_leaf(hp, jQ, jKb, jPE);

            float gi = 0.0f;
const float* w  = V.leaf_const(i, leaf);
const float* wb = V.leaf_const(i, leaf_bar);
for (int k = 0; k < hp.embedding_dim; k++) {
  float wk  = w  ? w[(size_t)k]  : 0.0f;
  float wbk = wb ? wb[(size_t)k] : 0.0f;
  gi += yg[(size_t)k] * (wbk - wk);
}
            float v = gi * Up(cK.u_min[(size_t)i]);

            int idx = i*hp.n_c + cK.r_min[(size_t)i];
            xgK[V.a[(size_t)idx]] += v;
            xgK[V.b[(size_t)idx]] -= v;
          }

          if (uPE < uQ && uPE < uK) {
            int jPEb = jPE ^ (1 << cPE.r_min[(size_t)i]);
            uint32_t leaf_bar = concat_leaf(hp, jQ, jK, jPEb);

            float gi = 0.0f;
const float* w  = V.leaf_const(i, leaf);
const float* wb = V.leaf_const(i, leaf_bar);
for (int k = 0; k < hp.embedding_dim; k++) {
  float wk  = w  ? w[(size_t)k]  : 0.0f;
  float wbk = wb ? wb[(size_t)k] : 0.0f;
  gi += yg[(size_t)k] * (wbk - wk);
}
            float delta = gi * Up(cPE.u_min[(size_t)i]);

            int rel = pos - pos1;
            size_t off = (size_t)rel * (size_t)hp.n_t * (size_t)hp.positional_dim
                       + (size_t)i * (size_t)hp.positional_dim
                       + (size_t)cPE.r_min[(size_t)i];
            pos_grad[off] += delta;
          }

          // Update the active leaf, but only allocate it after the 2nd visit.
          LUT::Leaf* plf = V.leaf_touch(i, leaf);
          if (plf) {
            float* ww = V.leaf_weights_mut(*plf);
            for (int k = 0; k < hp.embedding_dim; k++) ww[(size_t)k] -= lr * yg[(size_t)k];
            // importance update (cheap heuristic): magnitude of parameter update
            float imp = 0.0f;
            for (int k = 0; k < hp.embedding_dim; k++) imp += std::fabs(lr * yg[(size_t)k]);
            plf->importance_ema = 0.99f * plf->importance_ema + 0.01f * imp;
          }

        }
      }
    }

    for (size_t i = 0; i < positional.size(); i++) positional[i] -= lr * pos_grad[i];
  }
};

struct Model {
  HyperParams hp;

  std::vector<float> token_embedder; // [vocab][emb]
  std::vector<float> z;              // [context][emb]
  std::vector<int32_t> tokens;       // [context+1]

  std::vector<LUT> ffn;
  std::vector<std::vector<LUTCache>> ffn_cache;

  std::vector<std::vector<AttentionHead>> heads;

  LUT unembed;
  std::vector<LUTCache> unembed_cache;

  // Prune rarely-used/low-impact leaves across all LUTs, and collapse
  // identical leaves via exact canonicalization (performed inside LUT::prune).
  void prune_luts(uint32_t min_count, float min_importance) {
    for (auto& lut : ffn) lut.prune(min_count, min_importance);
    unembed.prune(min_count, min_importance);
    for (auto& layer : heads) {
      for (auto& h : layer) h.V.prune(min_count, min_importance);
    }
  }

  std::vector<float> output; // [context][vocab]

  // Deferred gradient accumulator. When egsa_accum_steps > 1, per‑step
  // gradients are accumulated in grad_acc and applied together after
  // egsa_accum_steps steps or when a commit condition passes. grad_acc_steps
  // counts how many forward/gradient collections have been accumulated. These
  // buffers are sized like `output` and are reset after each commit.
  std::vector<float> grad_acc;
  int grad_acc_steps = 0;
  EGSAState egsa;

  void init(const HyperParams& hp_, RNG& rng) {
    hp = hp_;

    token_embedder.resize((size_t)hp.vocab_size * (size_t)hp.embedding_dim);
    for (auto& v : token_embedder) v = rng.uniform_signed(1.0f);

    z.assign((size_t)hp.context * (size_t)hp.embedding_dim, 0.0f);
    tokens.assign((size_t)hp.context + 1, 0);

    ffn.resize((size_t)hp.num_layers);
    ffn_cache.resize((size_t)hp.num_layers);
    heads.resize((size_t)hp.num_layers);

    for (int l = 0; l < hp.num_layers; l++) {
      ffn[(size_t)l].init(hp, rng, hp.n_c, hp.embedding_dim);
      ffn_cache[(size_t)l].resize((size_t)hp.context);
      for (int pos = 0; pos < hp.context; pos++) ffn_cache[(size_t)l][(size_t)pos] = ffn[(size_t)l].make_cache();

      heads[(size_t)l].resize((size_t)hp.num_heads);
      for (int h = 0; h < hp.num_heads; h++) heads[(size_t)l][(size_t)h].init(hp, rng);
    }

    unembed.init(hp, rng, hp.n_c, hp.vocab_size);
    unembed_cache.resize((size_t)hp.context);
    for (int pos = 0; pos < hp.context; pos++) unembed_cache[(size_t)pos] = unembed.make_cache();

    output.assign((size_t)hp.context * (size_t)hp.vocab_size, 0.0f);

    // Allocate deferred gradient accumulator with the same shape as output.
    grad_acc.assign(output.size(), 0.0f);
    grad_acc_steps = 0;
    egsa = EGSAState{};
  }

  inline const float* emb_ptr(int token_id) const {
    return &token_embedder[(size_t)token_id * (size_t)hp.embedding_dim];
  }

  void load_snippet(const uint8_t* data, uint32_t start) {
    for (int pos = 0; pos < hp.context; pos++) {
      int t = (int)data[start + (uint32_t)pos];
      tokens[(size_t)pos] = t;
      std::memcpy(&z[(size_t)pos*(size_t)hp.embedding_dim], emb_ptr(t), (size_t)hp.embedding_dim*sizeof(float));
    }
    tokens[(size_t)hp.context] = (int)data[start + (uint32_t)hp.context];
  }

  void forward() {
    for (int l = 0; l < hp.num_layers; l++) {
      std::vector<float> x = z; // snapshot for attention reads
      for (int h = 0; h < hp.num_heads; h++) {
        heads[(size_t)l][(size_t)h].forward(x.data(), z.data()); // residual into z
      }

      for (int pos = 0; pos < hp.context; pos++) {
        float* zpos = &z[(size_t)pos*(size_t)hp.embedding_dim];
        ffn[(size_t)l].cache_index(zpos, ffn_cache[(size_t)l][(size_t)pos]);
        ffn[(size_t)l].forward(ffn_cache[(size_t)l][(size_t)pos], zpos);
      }
    }

    std::fill(output.begin(), output.end(), 0.0f);
    for (int pos = 0; pos < hp.context; pos++) {
      float* zpos = &z[(size_t)pos*(size_t)hp.embedding_dim];
      float* outp = &output[(size_t)pos*(size_t)hp.vocab_size];
      unembed.cache_index(zpos, unembed_cache[(size_t)pos]);
      unembed.forward(unembed_cache[(size_t)pos], outp);
    }
  }

  void backward(float lr) {
    std::vector<float> x_grad((size_t)hp.context*(size_t)hp.embedding_dim, 0.0f);
    std::vector<float> y_grad((size_t)hp.context*(size_t)hp.embedding_dim, 0.0f);

    for (int pos = 0; pos < hp.context; pos++) {
      float* xg = &x_grad[(size_t)pos*(size_t)hp.embedding_dim];
      float* og = &output[(size_t)pos*(size_t)hp.vocab_size]; // output holds grad after softmax-xent
      unembed.backward(unembed_cache[(size_t)pos], xg, og, lr);
    }

    for (int l = hp.num_layers - 1; l >= 0; l--) {
      y_grad = x_grad;
      for (int pos = 0; pos < hp.context; pos++) {
        float* xg = &x_grad[(size_t)pos*(size_t)hp.embedding_dim];
        float* yg = &y_grad[(size_t)pos*(size_t)hp.embedding_dim];
        ffn[(size_t)l].backward(ffn_cache[(size_t)l][(size_t)pos], xg, yg, lr);
      }

      y_grad = x_grad;
      for (int h = 0; h < hp.num_heads; h++) {
        heads[(size_t)l][(size_t)h].backward(x_grad.data(), y_grad.data(), lr);
      }
    }
  }

  EGSAPacket inspect_packet() {
    EGSAPacket p{};
    if (hp.context <= 0 || hp.vocab_size <= 0) return p;

    float mean_conf = 0.0f;
    float mean_ent = 0.0f;
    float mean_target = 0.0f;
    float mean_correct = 0.0f;

    std::vector<float> probs((size_t)hp.vocab_size);
    for (int pos = 0; pos < hp.context; pos++) {
      const float* logits = &output[(size_t)pos * (size_t)hp.vocab_size];
      std::memcpy(probs.data(), logits, (size_t)hp.vocab_size * sizeof(float));
      softmax_inplace(probs.data(), hp.vocab_size, hp.temp_train);

      int target = tokens[(size_t)pos + 1];
      int argmax = 0;
      float best = probs[0];
      float ent = 0.0f;
      for (int i = 0; i < hp.vocab_size; i++) {
        float pr = probs[(size_t)i];
        if (pr > best) { best = pr; argmax = i; }
        if (pr > 1e-20f) ent -= pr * std::log(pr);
      }
      float ent_norm = ent / std::log((float)hp.vocab_size + 1e-20f);
      mean_ent += ent_norm;
      mean_target += probs[(size_t)target];
      mean_conf += best;
      mean_correct += (argmax == target) ? 1.0f : 0.0f;
    }

    float inv_ctx = 1.0f / (float)hp.context;
    p.confidence = mean_conf * inv_ctx;
    p.target_prob = mean_target * inv_ctx;
    p.correct_rate = mean_correct * inv_ctx;
    p.entropy = mean_ent * inv_ctx;
    p.delta_entropy = p.entropy - egsa.entropy_ema;
    p.certainty = std::clamp(egsa.certainty_ema, 0.0f, 1.0f);
    const float entropy_risk = p.entropy;
    const float surprise_risk = 1.0f - p.target_prob;
    const float drift_risk = std::max(0.0f, p.delta_entropy);
    p.risk = std::clamp(0.55f * entropy_risk + 0.30f * surprise_risk + 0.15f * drift_risk, 0.0f, 1.5f);
    p.commit_score = p.confidence * p.certainty - hp.egsa_risk_lambda * p.risk;
    return p;
  }

  void update_egsa_state(const EGSAPacket& p, bool committed) {
    const float a = std::clamp(hp.egsa_state_ema, 0.0001f, 1.0f);
    egsa.entropy_ema = (1.0f - a) * egsa.entropy_ema + a * p.entropy;
    egsa.confidence_ema = (1.0f - a) * egsa.confidence_ema + a * p.confidence;
    egsa.risk_ema = (1.0f - a) * egsa.risk_ema + a * p.risk;
    egsa.correct_rate_ema = (1.0f - a) * egsa.correct_rate_ema + a * p.correct_rate;
    float calib = 1.0f - std::fabs(p.confidence - p.correct_rate);
    calib = std::clamp(calib, 0.0f, 1.0f);
    egsa.certainty_ema = (1.0f - a) * egsa.certainty_ema + a * calib;
    if (committed) egsa.committed_steps++; else egsa.skipped_steps++;
  }

  EGSAPacket training_step(float lr) {
    // Forward pass to compute logits in `output` and inspect the current packet
    forward();
    EGSAPacket p = inspect_packet();

    // Determine commit gating and learning rate scaling. lr_scale is reduced
    // during retries if the commit score fails to exceed the threshold. The
    // original EGSA logic is preserved here and applied on the *last* sample
    // prior to a deferred update when egsa_accum_steps > 1.
    float lr_scale = 1.0f;
    bool commit_flag = true;
    int retries = 0;

    if (hp.egsa_enable) {
      float score = p.commit_score;
      float scaled_risk = p.risk;
      commit_flag = false;
      while (retries <= hp.egsa_max_retries) {
        score = p.confidence * p.certainty - hp.egsa_risk_lambda * scaled_risk;
        if (score > hp.egsa_commit_threshold) { commit_flag = true; break; }
        retries++;
        lr_scale *= hp.egsa_retry_lr_scale;
        if (lr_scale < hp.egsa_min_lr_scale) break;
        scaled_risk = p.risk * lr_scale;
      }
      p.commit_score = score;
    }

    // Compute per‑sample gradient: softmax then subtract 1 for target index. We
    // accumulate these gradients in grad_acc when deferred updates are enabled.
    // We cannot directly use `output` for accumulation because `output` will be
    // overwritten on the next forward pass. Instead, we compute gradient in
    // place on `output`, add to grad_acc, and allow `output` to be overwritten
    // later.
    for (int pos = 0; pos < hp.context; pos++) {
      float* outp = &output[(size_t)pos * (size_t)hp.vocab_size];
      softmax_inplace(outp, hp.vocab_size, hp.temp_train);
      // Subtract 1 from the probability of the true target to get the gradient
      outp[(size_t)tokens[(size_t)pos + 1]] -= 1.0f;
      // Accumulate into grad_acc
      float* accp = &grad_acc[(size_t)pos * (size_t)hp.vocab_size];
      for (int i = 0; i < hp.vocab_size; i++) {
        accp[(size_t)i] += outp[(size_t)i];
      }
    }
    grad_acc_steps++;

    bool deferred = (hp.egsa_accum_steps > 1);
    bool apply_update = false;
    // Determine when to apply the aggregated update. When egsa_accum_steps==1
    // behave like the original training: apply immediately if commit_flag true.
    // When deferred, apply after accumulating egsa_accum_steps steps, and only
    // if the commit_flag for the last sample is true. This approximates the
    // recursion‑style update where weights remain unchanged during several
    // forward passes and then are updated in one batch.
    if (!deferred) {
      apply_update = commit_flag;
    } else {
      if (grad_acc_steps >= hp.egsa_accum_steps) {
        apply_update = commit_flag;
      }
    }

    // Populate packet fields for reporting. applied_lr_scale is non‑zero only
    // when we actually update weights this iteration. p.committed tracks
    // whether the model parameters were updated (true) or the gradient was
    // skipped (false). If deferred and we haven’t hit the accumulation window
    // yet, we don’t update even if commit_flag is true.
    p.applied_lr_scale = apply_update ? lr_scale : 0.0f;
    p.retries_used = retries;
    p.committed = apply_update;
    egsa.total_retries += (uint64_t)retries;

    if (apply_update) {
      // Average the accumulated gradient to maintain scale; this prevents
      // gradients from exploding when many steps are aggregated. The
      // aggregated gradient is copied into `output` as expected by
      // backward().
      float inv = 1.0f / (float)grad_acc_steps;
      for (size_t i = 0; i < grad_acc.size(); i++) {
        output[i] = grad_acc[i] * inv;
      }
      // Apply the aggregated gradient with scaled learning rate. This
      // single backward call updates all weights as if each of the
      // aggregated steps was applied with learning rate lr * lr_scale /
      // grad_acc_steps.
      backward(lr * lr_scale);
      // Reset accumulator
      std::fill(grad_acc.begin(), grad_acc.end(), 0.0f);
      grad_acc_steps = 0;
    } else {
      // If update not applied and we reached the accumulation window, reset
      // the accumulator to avoid indefinite growth. We do not update
      // weights in this case, effectively skipping these steps.
      if (deferred && grad_acc_steps >= hp.egsa_accum_steps) {
        std::fill(grad_acc.begin(), grad_acc.end(), 0.0f);
        grad_acc_steps = 0;
      }
    }

    // Update EGSA state, tracking commitment vs. skip to adjust running
    // EMAs. Even if the update is deferred, we still update the EMAs at
    // every step so that confidence, risk and certainty estimates adapt to
    // observed data.
    update_egsa_state(p, apply_update);
    return p;
  }

  int infer_next(RNG& rng, float temp_sample) {
    forward();
    float* outp = &output[(size_t)(hp.context - 1) * (size_t)hp.vocab_size];
    softmax_inplace(outp, hp.vocab_size, temp_sample);
    return sample_from_probs(outp, hp.vocab_size, rng);
  }
};
