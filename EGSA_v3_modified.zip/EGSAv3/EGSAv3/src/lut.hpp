#pragma once
#include "config.hpp"
#include "rng.hpp"
#include <vector>
#include <unordered_map>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <limits>
#include <algorithm>

inline int sgn(float x) { return (x > 0.0f) ? 1 : -1; } // 0 treated as negative
inline float Up(float u) {
  float a = 1.0f + std::fabs(u);
  return -0.5f * (float)sgn(u) / (a * a);
}

struct LUTCache {
  std::vector<int32_t> j;      // [n_t]
  std::vector<int32_t> r_min;  // [n_t]
  std::vector<float>   u_min;  // [n_t]
};

struct LUT {
  HyperParams hp;
  int total_n_c = 0;
  int y_dim     = 0;

  std::vector<int32_t> a;
  std::vector<int32_t> b;

// --- Leaf storage with sharing/canonicalization ---
// We store leaf weights in a shared pool. Leaves point to pool entries.
// This makes the *default zero leaf* shared across all untouched leaves,
// and enables exact de-duplication (canonicalization) of identical leaves.
struct Leaf {
  uint32_t pool_id = 0;     // index into pool
  uint32_t count = 0;       // visit count (not just update count)
  float importance_ema = 0.0f;
};

// Sparse leaves per table: allocate only rows we actually touch.
// Key: leaf index j (0..2^total_n_c-1)
std::vector<std::unordered_map<uint32_t, Leaf>> S;

// First-visit tracker: do not allocate a real leaf until it is visited twice.
// Key: leaf index j
std::vector<std::unordered_map<uint32_t, uint8_t>> seen_once;

// Shared weight vectors. pool[pool_id] is a vector<float>[y_dim].
std::vector<std::vector<float>> pool;
std::vector<uint32_t> pool_ref;

static uint64_t fnv1a64_bytes(const uint8_t* data, size_t n) {
  uint64_t h = 1469598103934665603ull;
  for (size_t i = 0; i < n; i++) { h ^= (uint64_t)data[i]; h *= 1099511628211ull; }
  return h;
}

void pool_init() {
  pool.clear();
  pool_ref.clear();
  pool.emplace_back(std::vector<float>((size_t)y_dim, 0.0f)); // id 0: shared zeros
  pool_ref.emplace_back(0);
}

uint32_t pool_add_copy(const std::vector<float>& v) {
  pool.push_back(v);
  pool_ref.push_back(0);
  return (uint32_t)(pool.size() - 1);
}

void pool_inc(uint32_t id) {
  if (id >= pool_ref.size()) return;
  pool_ref[(size_t)id] += 1;
}

void pool_dec(uint32_t id) {
  if (id >= pool_ref.size()) return;
  if (pool_ref[(size_t)id] > 0) pool_ref[(size_t)id] -= 1;
}

const float* leaf_const(int table, uint32_t j) const {
  const auto& mp = S[(size_t)table];
  auto it = mp.find(j);
  if (it == mp.end()) return nullptr;
  return pool[(size_t)it->second.pool_id].data();
}

// Return a pointer to a leaf if it is eligible for update.
// If this is the first time we've seen the leaf, we do NOT allocate it and
// return nullptr. On the second visit, we allocate the leaf (shared zeros) and
// return it. This keeps memory down by avoiding one-off leaves.
Leaf* leaf_touch(int table, uint32_t j) {
  auto& mp = S[(size_t)table];
  auto it = mp.find(j);
  if (it != mp.end()) {
    it->second.count += 1;
    return &it->second;
  }
  auto& once = seen_once[(size_t)table];
  auto it1 = once.find(j);
  if (it1 == once.end()) {
    once.emplace(j, 1);
    return nullptr;
  }
  // second visit: allocate leaf
  once.erase(it1);
  Leaf lf;
  lf.pool_id = 0;
  lf.count = 2; // visited twice
  lf.importance_ema = 0.0f;
  pool_inc(0);
  auto res = mp.emplace(j, lf);
  return &res.first->second;
}

// Ensure leaf has a unique pool vector before in-place modification.
float* leaf_weights_mut(Leaf& lf) {
  uint32_t id = lf.pool_id;
  if (id >= pool.size()) return nullptr;
  if (pool_ref[(size_t)id] > 1) {
    // detach
    std::vector<float> copy = pool[(size_t)id];
    pool_dec(id);
    uint32_t nid = pool_add_copy(copy);
    lf.pool_id = nid;
    pool_inc(nid);
    id = nid;
  }
  return pool[(size_t)id].data();
}

const std::vector<float>& leaf_vec(const Leaf& lf) const {
  return pool[(size_t)lf.pool_id];
}

// Exact canonicalization: merge leaves that have identical float vectors.
// (Byte-for-byte equality.) This is safe and fast enough to run periodically.
void canonicalize_exact() {
  std::unordered_map<uint64_t, uint32_t> rep;
  rep.reserve(1024);
  const size_t bytes = (size_t)y_dim * sizeof(float);
  for (auto& mp : S) {
    for (auto& kv : mp) {
      Leaf& lf = kv.second;
      uint32_t id = lf.pool_id;
      if (id >= pool.size()) continue;
      const uint8_t* ptr = (const uint8_t*)pool[(size_t)id].data();
      uint64_t h = fnv1a64_bytes(ptr, bytes);
      auto it = rep.find(h);
      if (it == rep.end()) { rep.emplace(h, id); continue; }
      uint32_t rid = it->second;
      if (rid == id) continue;
      if (pool[(size_t)rid].size() != pool[(size_t)id].size()) continue;
      if (std::memcmp(pool[(size_t)rid].data(), pool[(size_t)id].data(), bytes) == 0) {
        pool_dec(id);
        lf.pool_id = rid;
        pool_inc(rid);
      }
    }
  }
}

// Simple pruning: drop leaves that are rarely used and have low impact.
// Also performs exact canonicalization afterward to collapse identical leaves.
void prune(uint32_t min_count, float min_importance) {
  for (auto& mp : S) {
    for (auto it = mp.begin(); it != mp.end(); ) {
      const Leaf& lf = it->second;
      if (lf.count < min_count && lf.importance_ema < min_importance) {
        pool_dec(lf.pool_id);
        it = mp.erase(it);
      } else {
        ++it;
      }
    }
  }
  canonicalize_exact();
}


  void init(const HyperParams& hp_, RNG& rng, int total_n_c_, int y_dim_) {
    hp = hp_;
    total_n_c = total_n_c_;
    y_dim = y_dim_;

    a.resize((size_t)hp.n_t * (size_t)hp.n_c);
    b.resize((size_t)hp.n_t * (size_t)hp.n_c);

    for (int i = 0; i < hp.n_t; i++) {
      for (int r = 0; r < hp.n_c; r++) {
        int idx = i*hp.n_c + r;
        int aa = rng.uniform_int(0, hp.embedding_dim - 1);
        int bb;
        do { bb = rng.uniform_int(0, hp.embedding_dim - 1); } while (bb == aa);
        a[(size_t)idx] = aa;
        b[(size_t)idx] = bb;
      }
    }

    S.clear();
    S.resize((size_t)hp.n_t);
    seen_once.clear();
    seen_once.resize((size_t)hp.n_t);
    // NOTE: We do NOT allocate dense tables here. Leaves are allocated on demand.
    pool_init();
  }

  LUTCache make_cache() const {
    LUTCache c;
    c.j.assign((size_t)hp.n_t, 0);
    c.r_min.assign((size_t)hp.n_t, 0);
    c.u_min.assign((size_t)hp.n_t, 0.0f);
    return c;
  }

  void cache_index(const float* x, LUTCache& cache) const {
    for (int i = 0; i < hp.n_t; i++) {
      int ji = 0;
      float umin = std::numeric_limits<float>::infinity();
      int rmin = 0;
      for (int r = 0; r < hp.n_c; r++) {
        int idx = i*hp.n_c + r;
        float u = x[a[(size_t)idx]] - x[b[(size_t)idx]];
        if (u > 0.0f) ji |= (1 << r);
        if (std::fabs(u) < std::fabs(umin)) { umin = u; rmin = r; }
      }
      cache.j[(size_t)i] = ji;
      cache.r_min[(size_t)i] = rmin;
      cache.u_min[(size_t)i] = umin;
    }
  }

  void cache_pe_index(const float* u /*[n_t*pos_dim]*/, LUTCache& cache) const {
    for (int i = 0; i < hp.n_t; i++) {
      int ji = 0;
      float umin = std::numeric_limits<float>::infinity();
      int rmin = 0;
      for (int r = 0; r < hp.positional_dim; r++) {
        float val = u[i*hp.positional_dim + r];
        if (val > 0.0f) ji |= (1 << r);
        if (std::fabs(val) < std::fabs(umin)) { umin = val; rmin = r; }
      }
      cache.j[(size_t)i] = ji;
      cache.r_min[(size_t)i] = rmin;
      cache.u_min[(size_t)i] = umin;
    }
  }

  void forward(const LUTCache& cache, float* y /*[y_dim]*/) const {
  for (int i = 0; i < hp.n_t; i++) {
    uint32_t j = (uint32_t)cache.j[(size_t)i];
    const float* w = leaf_const(i, j);
    if (!w) continue;
    for (int k = 0; k < y_dim; k++) y[k] += w[(size_t)k];
  }
}


  void backward(const LUTCache& cache,
              float* x_grad /*[embedding_dim]*/,
              const float* y_grad /*[y_dim]*/,
              float lr) {
  // Exponential moving average factor for importance tracking
  const float alpha = 0.01f;

  for (int i = 0; i < hp.n_t; i++) {
    int j = cache.j[(size_t)i];
    int rmin = cache.r_min[(size_t)i];
    float umin = cache.u_min[(size_t)i];

    int jbar = (j ^ (1 << rmin));

    const float* w  = leaf_const(i, (uint32_t)j);
    const float* wb = leaf_const(i, (uint32_t)jbar);

    // If missing, treat as zero vector.
    float gi = 0.0f;
    for (int k = 0; k < y_dim; k++) {
      float wk  = w  ? w[(size_t)k]  : 0.0f;
      float wbk = wb ? wb[(size_t)k] : 0.0f;
      gi += y_grad[(size_t)k] * (wbk - wk);
    }
    float v = gi * Up(umin);

    int idx = i*hp.n_c + rmin;
    x_grad[a[(size_t)idx]] += v;
    x_grad[b[(size_t)idx]] -= v;

    // SGD update only on the active leaf j, but allocate only after 2nd visit.
    Leaf* plf = leaf_touch(i, (uint32_t)j);
    if (plf) {
      float* ww = leaf_weights_mut(*plf);
      for (int k = 0; k < y_dim; k++) ww[(size_t)k] -= lr * y_grad[(size_t)k];
      float imp = std::fabs(gi);
      plf->importance_ema = (1.0f - alpha) * plf->importance_ema + alpha * imp;
    }
  }
}
};



inline uint32_t concat_leaf(const HyperParams& hp, int Q, int K, int PE) {
  int shiftQ = hp.n_c + hp.positional_dim;
  int shiftK = hp.positional_dim;
  uint32_t j = ((uint32_t)Q << shiftQ) | ((uint32_t)K << shiftK) | (uint32_t)PE;
  return j;
}

inline size_t concat_index(const HyperParams& hp, int Q, int K, int PE, int y_dim) {
  uint32_t j = concat_leaf(hp, Q, K, PE);
  return (size_t)j * (size_t)y_dim;
}
