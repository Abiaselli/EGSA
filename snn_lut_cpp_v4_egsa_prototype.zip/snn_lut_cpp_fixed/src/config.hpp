#pragma once
#include <cstdint>
#include <cmath>

struct HyperParams {
  // Data
  int vocab_size = 256;      // bytes
  int context    = 32;

  // Model
  int embedding_dim  = 32;
  int positional_dim = 4;
  int num_layers     = 2;
  int num_heads      = 2;

  // LUT
  int n_t = 8;
  int n_c = 6;

  // Training
  int testing_length = 10000;
  float temp_train   = 1.0f;
  float temp_sample  = 0.4f;

  // checkpoint format version
  uint32_t ckpt_version = 4;

  // Dataset / checkpoint format knobs
  bool use_markers = false;
  bool ckpt_fp16  = true;

  // EGSA prototype controls
  bool  egsa_enable               = true;
  float egsa_risk_lambda          = 0.35f;
  float egsa_commit_threshold     = -0.35f;
  float egsa_high_risk_threshold  = 0.70f;
  int   egsa_max_retries          = 2;
  float egsa_retry_lr_scale       = 0.50f;
  float egsa_min_lr_scale         = 0.10f;
  float egsa_state_ema            = 0.02f;
};

inline float learning_rate_schedule(uint64_t t) {
  const float a = 1.0f / std::sqrt(1.0f + (float)t);
  const float b = ((float)t / 4000.0f) / std::sqrt(4000.0f);
  return (a < b) ? a : b;
}
